package com.example.shoppinglist.listBuilder

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ListBuilderViewModel : ViewModel() {

    var text = MutableLiveData<String>()

    init {
        text.value = ""
    }

    override fun onCleared() {
        super.onCleared()
    }

    fun updateText(){
        text.value = "lksadhjglksadhglksadhglk;sadhg;sadhg;sad;gssssssssssssssssssssssssssds"
    }
}