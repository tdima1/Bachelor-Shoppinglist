package com.example.shoppinglist.listBuilder


import android.databinding.DataBindingUtil
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders

import com.example.shoppinglist.R
import com.example.shoppinglist.databinding.FragmentListBuilderBinding

/**
 * A simple [Fragment] subclass.
 */
class ListBuilderFragment : Fragment() {

    private lateinit var viewModel: ListBuilderViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val binding: FragmentListBuilderBinding = DataBindingUtil.inflate(
            inflater, R.layout.fragment_list_builder, container, false)

        viewModel = ViewModelProviders.of(this).get(ListBuilderViewModel::class.java)

        binding.button1.setOnClickListener(){
            viewModel.updateText()
        }

        viewModel.text.observe(this, Observer { updatedText ->
            binding.textTest.text = updatedText
        })

        return binding.root
    }


}
